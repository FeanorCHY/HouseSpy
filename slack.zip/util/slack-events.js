module.exports = {
    url_verification:"url_verification",
    event_callback:"event_callback"
}